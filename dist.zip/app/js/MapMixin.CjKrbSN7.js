"use strict";
import{E as e,m as s}from"./core.CC0KSsv9.js";const p={methods:{showMap(a,t,m,o,M=!1){e.$emit(s.SHOW_MAP,{center:a,mode:t,location:m,selectCallback:o,viewOnly:M})},closeMap(){e.$emit(s.HIDE_MAP)}}};export{p as M};
