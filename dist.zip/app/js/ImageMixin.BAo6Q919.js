"use strict";
import{E as s}from"./core.CC0KSsv9.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
